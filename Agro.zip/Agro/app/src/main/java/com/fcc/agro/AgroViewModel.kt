package com.fcc.agro

import android.app.Application
import android.content.ContentValues
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fcc.agro.provider.AgroProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class AgroViewModel(application: Application) : AndroidViewModel(application) {

    private val _productsFlow = MutableSharedFlow<List<Product>>()
    val productsFlow = _productsFlow.asSharedFlow()

    // Cargar productos desde el Content Provider
    fun loadProducts() {
        viewModelScope.launch(Dispatchers.IO) {
            val cursor = getApplication<Application>().contentResolver.query(
                AgroProvider.CONTENT_URI, null, null, null, null
            )
            val list = ArrayList<Product>()
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    val id = cursor.getInt(0) // _id
                    val name = cursor.getString(1)
                    val price = cursor.getDouble(2)
                    val stock = cursor.getInt(3)
                    list.add(Product(id, name, price, stock))
                } while (cursor.moveToNext())
                cursor.close()
            }
            _productsFlow.emit(list)
        }
    }

    // Agregar nuevo producto
    fun addProduct(name: String, price: Double, stock: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val values = ContentValues()
            values.put(AgroDBHandler.COLUMN_NAME, name)
            values.put(AgroDBHandler.COLUMN_PRICE, price)
            values.put(AgroDBHandler.COLUMN_STOCK, stock)
            getApplication<Application>().contentResolver.insert(AgroProvider.CONTENT_URI, values)
            loadProducts() // Recargar lista
        }
    }

    // Lógica de VENTA (Restar Stock)
    fun sellProduct(product: Product, quantityToSell: Int) {
        if (product.stock >= quantityToSell) {
            viewModelScope.launch(Dispatchers.IO) {
                val newStock = product.stock - quantityToSell
                val values = ContentValues()
                values.put(AgroDBHandler.COLUMN_STOCK, newStock)

                val selection = "${AgroDBHandler.COLUMN_ID} = ?"
                val selectionArgs = arrayOf(product.id.toString())

                getApplication<Application>().contentResolver.update(
                    AgroProvider.CONTENT_URI,
                    values,
                    selection,
                    selectionArgs
                )
                loadProducts() // Actualizar la vista
            }
        } else {
            // Puedes manejar el error de "Stock insuficiente" en la UI
        }
    }
}