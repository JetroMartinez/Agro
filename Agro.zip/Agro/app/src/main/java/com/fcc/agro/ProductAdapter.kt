package com.fcc.agro

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter(
    private var productList: List<Product>,
    private val onSellClick: (Product) -> Unit // Callback para cuando se pulse vender
) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textName: TextView = view.findViewById(android.R.id.text1)
        val textDetails: TextView = view.findViewById(android.R.id.text2)
        // Nota: Usaremos un layout simple de Android que no tiene botón por defecto,
        // pero podemos usar el clic en el item para vender.
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Usamos un layout simple de lista predefinido en Android
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = productList[position]
        holder.textName.text = product.name
        holder.textDetails.text = "Precio: $${product.price} | Stock: ${product.stock}"

        // Al hacer clic en el elemento, simulamos una venta de 1 unidad
        holder.itemView.setOnClickListener {
            onSellClick(product)
        }
    }

    override fun getItemCount(): Int = productList.size

    fun updateList(newList: List<Product>) {
        productList = newList
        notifyDataSetChanged()
    }
}