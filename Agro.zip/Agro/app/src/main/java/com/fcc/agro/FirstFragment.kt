package com.fcc.agro

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.fcc.agro.databinding.FragmentFirstBinding
import kotlinx.coroutines.launch

class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: AgroViewModel
    private lateinit var adapter: ProductAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializar ViewModel
        viewModel = ViewModelProvider(this)[AgroViewModel::class.java]

        // Configurar RecyclerView y el evento de click para Venta
        adapter = ProductAdapter(emptyList()) { product ->
            // Lógica de venta al hacer clic: Vender 1 unidad
            if (product.stock > 0) {
                viewModel.sellProduct(product, 1)
                Toast.makeText(context, "Vendido 1 ${product.name}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Sin stock de ${product.name}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = adapter

        // Botón Agregar
        binding.btnAdd.setOnClickListener {
            val name = binding.editName.text.toString()
            val price = binding.editPrice.text.toString().toDoubleOrNull()
            val stock = binding.editStock.text.toString().toIntOrNull()

            if (name.isNotEmpty() && price != null && stock != null) {
                viewModel.addProduct(name, price, stock)
                // Limpiar campos
                binding.editName.text.clear()
                binding.editPrice.text.clear()
                binding.editStock.text.clear()
            } else {
                Toast.makeText(context, "Rellena todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Observar cambios en la base de datos
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.productsFlow.collect { products ->
                    adapter.updateList(products)
                }
            }
        }

        // Carga inicial
        viewModel.loadProducts()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}