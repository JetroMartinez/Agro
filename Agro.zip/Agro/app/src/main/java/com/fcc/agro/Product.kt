package com.fcc.agro

data class Product(
    var id: Int = 0,
    var name: String? = null,
    var price: Double = 0.0,
    var stock: Int = 0
) {
    // Constructor secundario para cuando creamos un producto nuevo sin ID aun
    constructor(name: String, price: Double, stock: Int) : this(0, name, price, stock)
}